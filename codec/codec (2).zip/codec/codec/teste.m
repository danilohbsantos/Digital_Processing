vteste= zeros(1:64)
